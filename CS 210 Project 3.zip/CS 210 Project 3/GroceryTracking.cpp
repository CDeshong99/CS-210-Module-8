//Cameron DeShong
//CS 210 Project Three 
// 12/12/2024

#include <iostream>
#include <fstream>
#include <map>
#include <string>
#include <iomanip>

using namespace std;

// Function to load item frequencies from the input file
map<string, int> loadFrequencies(const string& filename) {
    map<string, int> frequencies;
    ifstream inputFile(filename);

    if (!inputFile) {
        cerr << "Error: Unable to open input file: " << filename << endl;
        exit(1);
    }

    string item;
    while (inputFile >> item) {
        frequencies[item]++;
    }

    inputFile.close();
    return frequencies;
}

// Function to display the frequency of a specific item
void displayItemFrequency(const map<string, int>& frequencies) {
    string item;
    cout << "Enter the item name: ";
    cin >> item;

    if (frequencies.count(item)) {
        cout << item << " appears " << frequencies.at(item) << " times." << endl;
    }
    else {
        cout << item << " was not found in the list." << endl;
    }
}

// Function to display all item frequencies
void displayAllFrequencies(const map<string, int>& frequencies) {
    cout << "\nItem Frequencies:\n";
    for (const auto& pair : frequencies) {
        cout << pair.first << ": " << pair.second << endl;
    }
}

// Function to display a histogram of item frequencies
void displayHistogram(const map<string, int>& frequencies) {
    cout << "\nItem Frequency Histogram:\n";
    for (const auto& pair : frequencies) {
        cout << setw(12) << left << pair.first << string(pair.second, '*') << endl;
    }
}

// Function to write item frequencies to a file
void writeFrequenciesToFile(const map<string, int>& frequencies, const string& outputFilename) {
    ofstream outputFile(outputFilename);

    if (!outputFile) {
        cerr << "Error: Unable to write to output file: " << outputFilename << endl;
        return;
    }

    for (const auto& pair : frequencies) {
        outputFile << pair.first << " " << pair.second << endl;
    }

    outputFile.close();
    cout << "Frequencies have been written to " << outputFilename << "." << endl;
}

int main() {
    const string inputFilename = "CS210_Project_Three_Input_File.txt";
    const string outputFilename = "frequency.dat";

    // Load frequencies from the input file
    map<string, int> frequencies = loadFrequencies(inputFilename);

    int choice;
    do {
        // Display the menu
        cout << "\nMenu:\n";
        cout << "1. Look up the frequency of a specific item\n";
        cout << "2. Display all item frequencies\n";
        cout << "3. Display a histogram of item frequencies\n";
        cout << "4. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            displayItemFrequency(frequencies);
            break;
        case 2:
            displayAllFrequencies(frequencies);
            break;
        case 3:
            displayHistogram(frequencies);
            break;
        case 4:
            writeFrequenciesToFile(frequencies, outputFilename);
            cout << "Exiting program. Goodbye!" << endl;
            break;
        default:
            cout << "Invalid choice. Please try again." << endl;
        }
    } while (choice != 4);

    return 0;
}
